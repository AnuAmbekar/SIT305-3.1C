package com.example.myapplication;

public class QuestionAnswer {
    public static String questions[] = {
            "Who painted the Mona Lisa",
            "What is 1 + 1",
            "How many states are there in Australia"
    };

    public static String answers[][] = {
            {"Leonardo Da Vinci", "Leonardo DiCaprio", "Albert Einstein"},
            {"3", "2", "1"},
            {"8", "6", "7"}
    };

    public static String correctAnswers[] = {
            "Leonardo Da Vinci",
            "2",
            "6"
    };


}
